<aside id="menu">
    <div id="navigation">
       

        <ul class="nav" id="side-menu">
            <li class="active">
                <a href="deshboard.php"> <span class="nav-label">Dashboard</span> <span class="label label-success pull-right">v.1</span> </a>
            </li>
            
        
            
            <li>
                <a href="change_password.php"><span class="nav-label">Change Password</span></span> </a>
              
            </li>
          
          <li>
                <a href="create_category.php"><span class="nav-label">Category </span></span> </a>
              
            </li>
             <li>
                <a href="subcategory.php"><span class="nav-label">Subcategory</span></span> </a>
              
            </li>
            <li>
                <a href="insert_product.php"><span class="nav-label">Add Product</span></span> </a>
              
            </li>
           
             <li>
                <a href="logout.php"><span class="nav-label">Logout</span></span> </a>
              
            </li>


        </ul>
    </div>
</aside>

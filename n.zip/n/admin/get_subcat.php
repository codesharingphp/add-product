<?php
include('includes/config.php');
if(!empty($_POST["cat_id"])) 
{
 $id=intval($_POST['cat_id']);

$query=mysqli_query($connection,"SELECT * FROM subcategory WHERE cat_id=$id");
?>
<option value="">Select Subcategory</option>
<?php
 while($row=mysqli_fetch_array($query))
 {
  ?>
  <option value="<?php echo htmlentities($row['id']); ?>"><?php echo htmlentities($row['subcategory']); ?></option>
  <?php
 }
}
?>
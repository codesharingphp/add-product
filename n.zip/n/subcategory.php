<?php include("header.php");?>
<?php error_reporting(0);?>
<!--Page header & Title-->
<section id="page_header">
<div class="page_title">
  <div class="container">
    <div class="row">
   <?php $sql=mysqli_query($con,"select id,category from category");
  while($row=mysqli_fetch_array($sql))
  {
    ?>
  <a href="subcategory.php?id=<?php echo $row['id'];?>"><?php echo $row['category'];?></a>
   
</div> 
<?php }?>
</div>
</div>  
</section>
<section id="news" class="bg_grey padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-center">
     
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="cheffs_wrap_slider">
          <div id="news-slider" class="owl-carousel">
           <?php
$getCat = "SELECT * FROM `category` where cat_id='".$id."'";
$runGetcat = mysqli_query($connection,$getCat);
while($row = mysqli_fetch_array($runGetcat)) {
?>
          ?>
             <div class="item">
              <div class="news_content">
                 <a href="upper_subcategory.php">
                   <img  src="<?php echo 'admin/uploads/product/'.$row['productimage'];?>" >
                 </a>

              <div class="comment_text">
                 <h3><?php echo $row['productname'];?></h3>
                 <p><?php echo $row['productdescription'];?></p>
                 <p><?php echo $row['productprice'];?></p>
               </div>

               <button type="button" class="btn btn-warning">Order Now</button>
              </div>
            </div>
         <?php  }
           
            ?>
           
       
                        
        </div>
      </div>
    </div>
  </div>
</section>





<?php include("footer.php");?>
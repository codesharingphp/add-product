<?php include("config.php");?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>BiryaniBala</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/bistro-icons.css">
<link rel="stylesheet" type="text/css" href="css/animate.min.css">
<link rel="stylesheet" type="text/css" href="css/settings.css">
<link rel="stylesheet" type="text/css" href="css/navigation.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css">
<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
<link rel="stylesheet" type="text/css" href="css/zerogrid.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/loader.css">
<link rel="shortcut icon" href="images/favicon.png">

<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

</head>

<body>


<!--Topbar-->
<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="pull-left hidden-xs">BIRYANIBALA Foods and Restaurant, the Best in Town</p>
        <p class="pull-right"><i class="fa fa-phone"></i>Order Online +9999999999</p>
      </div>
    </div>
  </div>
</div>

<!--Header-->
<header id="main-navigation">
  <div id="navigation" data-spy="affix" data-offset-top="20">
    <div class="container">
      <div class="row">
      <div class="col-md-12">
        <nav class="navbar navbar-default">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#fixed-collapse-navbar" aria-expanded="false"> 
            <span class="icon-bar top-bar"></span> <span class="icon-bar middle-bar"></span> <span class="icon-bar bottom-bar"></span> 
            </button>
           <a class="navbar-brand" href="index.php"><img src="images/logo.png" alt="logo" class="img-responsive"  style="width: 100px;"></a> 
         </div>
        
            <div id="fixed-collapse-navbar" class="navbar-collapse collapse navbar-right">
              <ul class="nav navbar-nav" >
                <li class="active" >
                   <a href="index.php" style="background-color: red">Home</a>
                   
                </li>

    
                    <li><a href="about.php">About Us</a></li>


<li><a href="#">Menu</a>
<ul >
<?php
$getCat = "SELECT * from category";
$runGetcat = mysqli_query($connection,$getCat);
while($row = mysqli_fetch_array($runGetcat)) {
?>
<li class="dropdown"><a href="subcategory.php?id=<?php echo $row['id'] ?>"><?php echo $row['category'] ?></a>
<ul>
<?php
$getsubCat = "SELECT * from subcategory where cat_id='".$row['id']."'";
$runGetsubcat = mysqli_query($connection,$getsubCat);
while($subrow = mysqli_fetch_array($runGetsubcat)){
?>
<li class="dropdown"><a href="productbysubcat.php?id=<?php echo $subrow['id'] ?>"><?php echo $subrow['subcategory'] ?></a></li>
<?php
}
?>
</ul>
</li>
<?php
}
?>
</ul>
</li>
<li><a href="gallery.php">Gallery</a></li>
<li><a href="order.php">Order Now</a></li>
</ul>

</div>
</nav>
</div>
</div>
</div>
</div>
</header>





<style type="text/css">
ul {
  list-style: none;
  padding: 0;
  margin: 0;

  /*background: #1bc2a2;*/
}

ul li {
  /*display: block;*/
  position: relative;
  float: left;

  /*background: #1bc2a2;*/
}
li ul { display: none; 
background-color:#ddd;

color:red;}

ul li a {
  display: block;
  padding: 1em;
  text-decoration: none;
  white-space: nowrap;
  color: red;

}

ul li a:hover { background: #2c3e50; }
li:hover > ul {
  display: block;
  position: absolute;

}

li:hover li { float: none; }

li:hover a {  }

li:hover li a:hover { background: #2c3e50; }

.main-navigation li ul li { border-top: 0; }
ul ul ul {
  left: 85%;
  top: 0;
}
ul:before,
ul:after {
  content: " "; /* 1 */
  display: table; /* 2 */
}

ul:after { clear: both; }
</style>